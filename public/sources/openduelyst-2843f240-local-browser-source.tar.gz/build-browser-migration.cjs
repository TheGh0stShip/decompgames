const path=require('path'),fs=require('fs');
const browserify=require('./probe-toolchain/node_modules/browserify');
const coffeeify=require('./probe-toolchain/node_modules/coffeeify');
const b=browserify(path.join(__dirname,'browser-migration-entry.js'),{basedir:__dirname,paths:[path.join(__dirname,'source'),path.join(__dirname,'probe-toolchain/node_modules')],extensions:['.js','.coffee']});
b.require(require.resolve('./firebase-legacy-database-bridge'),{expose:'firebase'});
b.transform(coffeeify);
b.transform(require('./probe-toolchain/node_modules/hbsfy'));
require('./deterministic-glsl-dependencies.cjs')(__dirname);
b.transform(require('./probe-toolchain/node_modules/glslify'));
const graph=[];b.on('dep',row=>graph.push({id:row.id,file:row.file,deps:row.deps}));
b.bundle((error,buffer)=>{fs.writeFileSync(path.join(__dirname,'migration-dependency-graph.json'),JSON.stringify(graph));if(error){fs.writeFileSync(path.join(__dirname,'browser-renderer-build-error.txt'),String(error));console.error(String(error));process.exitCode=1;return;}fs.writeFileSync(path.join(__dirname,'browser-migration-probe.js'),buffer);console.log(JSON.stringify({bytes:buffer.length,scope:'SDK browser bundle only; no renderer/gameplay'}));});




