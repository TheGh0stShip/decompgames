const Sandbox=require('./source/app/sdk/challenges/sandbox.coffee');
const GameSession=require('./source/app/sdk/gameSession.coffee');
const FactionFactory=require('./source/app/sdk/cards/factionFactory.coffee');
window.duelystLocalSDKProbe={Sandbox,GameSession,FactionFactory,DrawStartingHandAction:require('./source/app/sdk/actions/drawStartingHandAction.coffee')};

