# OpenDuelyst private attribution review

PRIVATE CANDIDATE. This evidence index is not a final legal clearance or release certificate. Existing JavaScript game adaptation; no WASM/decomp/clean-room claim.

## Runtime dependency evidence

| Package | Version | Declaration | Evidence |
| --- | --- | --- | --- |
| @firebase/app | 0.1.10 | Apache-2.0 | Recovered/author-linked text retained |
| @firebase/database | 0.2.1 | Apache-2.0 | Recovered/author-linked text retained |
| @firebase/logger | 0.1.0 | Apache-2.0 | Recovered/author-linked text retained |
| @firebase/polyfill | 0.3.0 | Apache-2.0 | Recovered/author-linked text retained |
| @firebase/util | 0.1.10 | Apache-2.0 | Recovered/author-linked text retained |
| @socket.io/component-emitter | 3.1.2 | MIT | Root notice retained |
| available-typed-arrays | 1.0.7 | MIT | Root notice retained |
| backbone | 1.2.1 | MIT | Root notice retained |
| backbone-virtual-collection | 0.6.6 | Legacy metadata/header evidence | Recovered/author-linked text retained |
| base64-js | 1.5.1 | MIT | Root notice retained |
| bluebird | 2.11.0 | MIT | Root notice retained |
| browser-resolve | 2.0.0 | MIT | Root notice retained |
| browserify | 17.0.1 | MIT | Root notice retained |
| buffer | 5.2.1 | MIT | Root notice retained |
| call-bind | 1.0.9 | MIT | Root notice retained |
| call-bind-apply-helpers | 1.0.2 | MIT | Root notice retained |
| call-bound | 1.0.4 | MIT | Root notice retained |
| clipboard | 1.7.1 | MIT | Recovered/author-linked text retained |
| colors | 1.4.0 | MIT | Root notice retained |
| convict | 6.2.2 | Apache-2.0 | Root notice retained |
| debug | 2.6.9 | MIT | Root notice retained |
| debug | 4.3.7 | MIT | Root notice retained |
| debug | 4.3.7 | MIT | Root notice retained |
| debug | 4.4.3 | MIT | Root notice retained |
| define-data-property | 1.1.4 | MIT | Root notice retained |
| delegate | 3.2.0 | MIT | Recovered/author-linked text retained |
| dunder-proto | 1.0.1 | MIT | Root notice retained |
| engine.io-client | 6.5.4 | MIT | Root notice retained |
| engine.io-parser | 5.2.3 | MIT | Root notice retained |
| enum | 2.5.0 | Legacy metadata/header evidence | Root notice retained |
| es-define-property | 1.0.1 | MIT | Root notice retained |
| es-errors | 1.3.0 | MIT | Root notice retained |
| es-object-atoms | 1.1.2 | MIT | Root notice retained |
| events | 3.3.0 | MIT | Root notice retained |
| firebase | 4.12.1 | Apache-2.0 | Recovered/author-linked text retained |
| for-each | 0.3.5 | MIT | Root notice retained |
| function-bind | 1.1.2 | MIT | Root notice retained |
| generator-function | 2.0.1 | MIT | Root notice retained |
| get-intrinsic | 1.3.0 | MIT | Root notice retained |
| get-proto | 1.0.1 | MIT | Root notice retained |
| good-listener | 1.2.2 | MIT | Recovered/author-linked text retained |
| gopd | 1.2.0 | MIT | Root notice retained |
| handlebars | 4.5.3 | MIT | Root notice retained |
| has-property-descriptors | 1.0.2 | MIT | Root notice retained |
| has-symbols | 1.1.0 | MIT | Root notice retained |
| has-tostringtag | 1.0.2 | MIT | Root notice retained |
| hasown | 2.0.4 | MIT | Root notice retained |
| hbsfy | 2.8.1 | MIT | Root notice retained |
| i18next | 3.4.4 | MIT | Root notice retained |
| ieee754 | 1.2.1 | BSD-3-Clause | Root notice retained |
| inherits | 2.0.4 | ISC | Root notice retained |
| is-arguments | 1.2.0 | MIT | Root notice retained |
| is-buffer | 1.1.6 | MIT | Root notice retained |
| is-callable | 1.2.7 | MIT | Root notice retained |
| is-generator-function | 1.1.2 | MIT | Root notice retained |
| is-regex | 1.2.1 | MIT | Root notice retained |
| is-typed-array | 1.1.15 | MIT | Root notice retained |
| isomorphic-fetch | 2.2.1 | MIT | Root notice retained |
| jquery | 2.1.4 | Legacy metadata/header evidence | Recovered/author-linked text retained |
| js-base64 | 2.6.4 | BSD-3-Clause | Root notice retained |
| lodash.clonedeep | 4.5.0 | MIT | Root notice retained |
| math-intrinsics | 1.1.0 | MIT | Root notice retained |
| moment | 2.29.4 | MIT | Root notice retained |
| ms | 2.0.0 | MIT | Root notice retained |
| ms | 2.1.3 | MIT | Root notice retained |
| object-inspect | 1.13.4 | MIT | Root notice retained |
| os-browserify | 0.3.0 | MIT | Root notice retained |
| parse-ms | 2.1.0 | MIT | Root notice retained |
| path-browserify | 1.0.1 | MIT | Root notice retained |
| possible-typed-array-names | 1.1.0 | MIT | Root notice retained |
| pretty-ms | 7.0.1 | MIT | Root notice retained |
| process | 0.11.10 | MIT | Root notice retained |
| promise-polyfill | 7.1.2 | MIT | Root notice retained |
| punycode | 1.4.1 | MIT | Root notice retained |
| qs | 6.16.0 | BSD-3-Clause | Root notice retained |
| safe-regex-test | 1.1.0 | MIT | Root notice retained |
| select | 1.1.2 | MIT | Recovered/author-linked text retained |
| semver | 5.7.2 | ISC | Root notice retained |
| set-function-length | 1.2.2 | MIT | Root notice retained |
| side-channel | 1.1.1 | MIT | Root notice retained |
| side-channel-list | 1.0.1 | MIT | Root notice retained |
| side-channel-map | 1.0.1 | MIT | Root notice retained |
| side-channel-weakmap | 1.0.2 | MIT | Root notice retained |
| socket.io-client | 4.7.2 | MIT | Root notice retained |
| socket.io-parser | 4.2.7 | MIT | Root notice retained |
| store2 | 2.14.2 | (MIT OR GPL-3.0) | Recovered/author-linked text retained |
| timers-browserify | 1.4.2 | Legacy metadata/header evidence | Root notice retained |
| tiny-emitter | 2.1.0 | MIT | Root notice retained |
| tslib | 1.14.1 | 0BSD | Root notice retained |
| underscore | 1.8.3 | MIT | Root notice retained |
| url | 0.11.4 | MIT | Root notice retained |
| util | 0.12.5 | MIT | Root notice retained |
| validator | 3.43.0 | MIT | Root notice retained |
| web-animations-js | 2.1.3 | Apache2 | Recovered/author-linked text retained |
| whatwg-fetch | 3.6.20 | MIT | Root notice retained |
| which-typed-array | 1.1.24 | MIT | Root notice retained |
| yargs-parser | 20.2.9 | ISC | Root notice retained |

## Separate vendor scripts

- jquery: MIT header and version-specific upstream full text retained; Sizzle inclusion noted in distributed header; SHA256 b2215cce5830e2350b9d420271d9bd82340f664c3f60f0ea850f7e9c0392704e.
- underscore: Audit evidence only; nested components and missing notices remain to review; SHA256 4b328e42c558197d5b99d7727cfcc60bac9763fad660651230e8baf93f6067ed.
- backbone: Audit evidence only; nested components and missing notices remain to review; SHA256 c27c8ad6ec8e148ed22a32035d67582e6affcdfa234e2cb2fac6611dbfd1781a.
- marionette: MIT root text plus bundled component copyright/MIT headers located; full attribution packaging pending; SHA256 92f60e3c2ab78e1a9205ecc1359123e5bfb700d238b3663bd1c65fc760bc8cbe.
- backfire: Audit evidence only; nested components and missing notices remain to review; SHA256 115bde5331c2e647927da713e460fd5ad55979fed32ced4617b05de95dc55b3c.
- cocos: Audit evidence only; nested components and missing notices remain to review; SHA256 2924041981363269bd5136aae2fcfba516551730079b3b7f39ece3c7e69850bf.
- ccConfig: Pinned project configuration under project CC0; no vendor code payload; SHA256 cc93708cab0bcf9c800fe4813070c6b998c3710fa51bddf74058104a66c4d7af.

Cocos nested TIFF and zlib MIT notices retained. Restrictive Spine module excluded by recorded AST adaptation and runtime regression.

## Build tools

103 loaded tool package roots inventoried; 116 local root/header/README notice records. Remaining full original notice gaps:
- object-keys 0.4.0: retain published MIT/ISC declaration and reference text; original publisher/origin attribution not certified complete.
- glslify-deps 1.3.2: retain published MIT/ISC declaration and reference text; original publisher/origin attribution not certified complete.
- @choojs/findup 0.2.1: retain published MIT/ISC declaration and reference text; original publisher/origin attribution not certified complete.

object-keys credited-origin MIT notices retained separately; exact copied revision unverified. Browserify polyfill/support roots added for source reconstruction need the same final packaging-scope review.

## Asset and verification scope

292 pinned project-media files, no shipped font/audio payloads. Preserve individual git/actual SHA256 provenance and explicit text line-ending conversion evidence. Platform fonts have no CC0 claim.

Independent deterministic build and integrated controls pass. Full combat-match completion remains unverified. Do not deploy until remaining attribution and gameplay scope are resolved, then reconcile and commit/push GitHub main.
