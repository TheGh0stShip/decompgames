// Authored CC0 compatibility entry for the private local-browser experiment.
// Uses real Apache-2.0 Firebase database references. Legacy account/auth APIs
// are outside this local-game experiment and are not claimed compatible.
const firebase=require('./firebase-migration-toolchain/node_modules/firebase/app');
require('./firebase-migration-toolchain/node_modules/firebase/database');
const apps=new Map();
function LegacyDatabaseReference(url){
 const parsed=new URL(url);const origin=parsed.origin;
 let app=apps.get(origin);
 if(!app){app=firebase.initializeApp({databaseURL:origin},'duelyst-db-'+apps.size);apps.set(origin,app);}
 return app.database().refFromURL(url);
}
LegacyDatabaseReference.ServerValue=firebase.database.ServerValue;
LegacyDatabaseReference.sdkVersion=firebase.SDK_VERSION;
module.exports=LegacyDatabaseReference;
