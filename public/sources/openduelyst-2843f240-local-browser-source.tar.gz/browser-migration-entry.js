window.Firebase=require('./firebase-legacy-database-bridge');
require('i18next').init({lng:'en',fallbackLng:'en',contextSeparator:'$',resources:{en:{translation:require('./private-en-locale.json')}}});
window.duelystRendererProbe={Scene:require('./source/app/view/Scene.js'),PackageManager:require('./source/app/ui/managers/package_manager'),packages:require('./source/app/data/packages')};
require('./browser-sdk-entry');

const pointer=require('./source/app/common/utils/utils_pointer');
const EventBus=require('./source/app/common/eventbus');
const EVENTS=require('./source/app/common/event_types');
window.duelystRendererProbe.connectPointer=function(){
 const canvas=document.getElementById('app-gamecanvas');
 for(const [dom,method,type] of [['mousemove','setPointerFromMoveEvent','pointer_move'],['mousedown','setPointerFromDownEvent','pointer_down'],['mouseup','setPointerFromUpEvent','pointer_up']]){
 canvas.addEventListener(dom,function(e){const rect=canvas.getBoundingClientRect();pointer[method]({pageX:e.clientX,pageY:e.clientY,which:e.button+1},rect.height,rect.left,rect.top);const p=pointer.getPointerEvent();p.type=EVENTS[type];p.target=canvas;EventBus.getInstance().trigger(p.type,p);window.duelystRendererProbe.Scene.current().getEventBus().trigger(p.type,p);});
 }
 canvas.addEventListener('contextmenu',e=>e.preventDefault());
};
window.RSX=require('./source/app/data/resources');
