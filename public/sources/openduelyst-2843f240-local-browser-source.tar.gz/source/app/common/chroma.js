// Independently authored disabled peripheral-lighting adapter. CC0-1.0.
// Provides only the application-facing interface; no device or network operations.
class Color {
 constructor(red,green,blue){
  if(typeof red==='string'){
   const text=red.replace(/^#/,'');
   this.r=parseInt(text.slice(0,2),16)||0;
   this.g=parseInt(text.slice(2,4),16)||0;
   this.b=parseInt(text.slice(4,6),16)||0;
  }else{this.r=Number(red)||0;this.g=Number(green)||0;this.b=Number(blue)||0;}
 }
}
const disabled=()=>Promise.resolve();
module.exports={Color,setAll:disabled,flashTurnTimer:disabled,flashAction:disabled,flashActionThrottled:disabled};
