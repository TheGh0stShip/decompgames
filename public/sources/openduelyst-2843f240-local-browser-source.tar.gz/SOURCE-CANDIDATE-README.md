# OpenDuelyst private local-browser build candidate

Status: PRIVATE CANDIDATE. License/attribution review and full combat-match verification remain unfinished. Do not deploy this archive as an approved release.

This adapts an existing JavaScript game. It is not WebAssembly, a retail decompilation, or a certified clean-room rewrite. Project CC0 and dependency MIT/Apache/BSD/ISC/0BSD licenses are retained separately.

Build with Node.js 24.19.0:

    node build-browser-migration.cjs

Selected dependencies and build tools are included; npm install is not required for the verified build. Expected browser-migration-probe.js SHA256:
22b56c43c86d83caecb13b625081aa03474d0fc14e6a615194578b2ac88392e6

The independent source copy produced byte-identical output. Browserify has an explicit basedir; an authored build adapter makes GLSL dependency IDs deterministic without editing shader operations.

private-player.html and private-player-bootstrap.js define the local two-player Sandbox host. Runtime media is separately inventoried; this source archive alone is not a complete served player. The candidate excludes Firebase 2.0.3, the Spine runtime, audio payloads, font payloads and embedded-font CSS. The Firebase compatibility entry uses real Apache SDK database references; legacy account/auth features are unsupported/unverified. Platform fonts are not relabeled CC0.

Local save/reload/continued card action, restart, ordinary movement, unit summon, targeted spell damage, artifact effect, turn swap and resignation have scoped browser verification. Full combat match completion, all cards/modes, online play, cross-device storage and mobile controls remain unverified. Keep audio disabled.

Collected notices live in candidate-notices. Some author-linked license pages use a current copyright year; retain the exact distributed release headers alongside them. Collection is audit evidence, not blanket clearance of every embedded component. Build-tool and nested notice review remains required.

Reconcile main on GitHub and commit/push release files before any future site deployment. Claude owns Halo and Mario Party projects.
