// Authored CC0 build adapter. Retains upstream glslify-bundle implementation.
const path=require('path');
module.exports=function(root){
 const key=require.resolve('./probe-toolchain/node_modules/glslify-bundle');
 const bundle=require(key);
 require.cache[key].exports=function(deps){
  const sorted=deps.slice().sort((a,b)=>{const x=path.relative(root,a.file).replace(/\\/g,'/');const y=path.relative(root,b.file).replace(/\\/g,'/');return x<y?-1:x>y?1:0;});
  const ids=new Map(sorted.map((d,i)=>[d.id,i]));
  const stable=sorted.map(d=>Object.assign({},d,{id:ids.get(d.id),deps:Object.fromEntries(Object.entries(d.deps).map(([k,v])=>{if(!ids.has(v))throw Error('Unresolved GLSL dependency');return [k,ids.get(v)];}))}));
  return bundle(stable);
 };
};
