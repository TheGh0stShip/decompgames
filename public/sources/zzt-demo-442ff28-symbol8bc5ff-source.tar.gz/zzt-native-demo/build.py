from pathlib import Path
import os,shutil,subprocess,sys
root=Path(__file__).parent
out=root/'build';out.mkdir(exist_ok=True)
compiler=os.environ.get('EMXX') or shutil.which('em++')
if not compiler:raise SystemExit('Set EMXX to em++ executable, or place em++ on PATH.')
sources=['src/assets.cpp', 'src/driver.cpp', 'src/editor.cpp', 'src/elements.cpp', 'src/file_selector.cpp', 'src/filesystem.cpp', 'src/game.cpp', 'src/high_scores.cpp', 'src/oop.cpp', 'src/sounds.cpp', 'src/txtwind.cpp', 'src/user_interface.cpp', 'src/user_interface_slim.cpp', 'src/user_interface_super_zzt.cpp', 'src/utils/iostream.cpp', 'src/utils/mathutils.cpp', 'src/utils/stringutils.cpp', 'src/world_serializer.cpp', 'src/driver_sdl2.cpp', 'src/filesystem_posix.cpp', 'src/audio_simulator.cpp', 'src/audio_simulator_bandlimited.cpp']
args=([sys.executable,compiler] if compiler.endswith(".py") else [compiler])+[*[str(root/s) for s in sources],'-I'+str(root/'src'),'-I'+str(root/'authored'),'-std=c++20','-O1','-pthread','-sUSE_SDL=2','-sPTHREAD_POOL_SIZE=3','-sPROXY_TO_PTHREAD=1','-sOFFSCREEN_FRAMEBUFFER=1','-sALLOW_MEMORY_GROWTH=1','-sFORCE_FILESYSTEM=1','-sEXPORTED_RUNTIME_METHODS=["FS"]']
for name in ['ASCII.BMP','DEMO.ZZT','ABOUT.HLP']:args+=['--preload-file',str(root/'authored'/name)+'@/'+name]
args+=['-o',str(out/'openzoo.js')]
subprocess.run(args,check=True)
shutil.copyfile(root/'player.html',out/'index.html')

shutil.copyfile(root/"save-validator.js",out/"save-validator.js")
