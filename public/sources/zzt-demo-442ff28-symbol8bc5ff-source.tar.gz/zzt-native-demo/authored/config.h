#define HAVE_GETCWD 1
#define HAVE_QSORT 1
#define HAVE_REALPATH 1
#define HAVE_STRNLEN 1
