# Source archive preparation

Status: private incomplete candidate. Do not upload until content/release verification gates pass.

Explicit allowlist for the eventual archive: root MIT license, src Go code/go.mod/go.sum, authored src/assets/_data files validated by replacement-asset-manifest.json, generator, browser wrapper/Go wasm_exec.js, build recipe, authored shader-mask adapter changes, replacement asset CC0 text and full third-party notices. Retain upstream revision and a changed-source patch. Default recipe must omit robodenprobe; omit tutorial_probe_wasm.go and use the no-op helper for source release.

Exclude original retail/Roboden media, Git history, module/toolchain caches, private screenshots/profile logs, diagnostic WASM, ROM reconstruction research, machine-specific paths and any generated source snippets lacking audited provenance. Dependencies should use pinned module resolution with notices; archive vendoring is a separate closure review, not automatic copying of the whole module cache.

The geometric sheets, silent soundtrack, pass-through effects and incomplete readable labels remain provisional. A source archive does not convert this pack to a content-complete game or the MIT source to CC0. Full tutorial completion/save evidence is diagnostic build13; uninstrumented build14 verifies tutorial startup/settings only.
