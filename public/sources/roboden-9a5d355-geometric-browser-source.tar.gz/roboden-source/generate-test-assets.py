from pathlib import Path
import re,json,hashlib,wave,math
from PIL import Image,ImageDraw
root=Path(__file__).parent; src=root/'src'; out=src/'assets/_data'; manifest=[]
# Independently written block-letter patterns; no bundled or system font rasterization.
glyphs={
 'R':['1110','1001','1110','1010','1001'], 'O':['0110','1001','1001','1001','0110'],
 'B':['1110','1001','1110','1001','1110'], 'D':['1110','1001','1001','1001','1110'],
 'E':['1111','1000','1110','1000','1111'], 'N':['1001','1101','1011','1001','1001'],
 'T':['1111','0110','0110','0110','0110'], 'S':['0111','1000','0110','0001','1110']}
def draw_label(draw,label,x,y,scale=4):
 for ch in label:
  for row,bits in enumerate(glyphs.get(ch,[])):
   for col,bit in enumerate(bits):
    if bit=='1':draw.rectangle((x+col*scale,y+row*scale,x+(col+1)*scale-1,y+(row+1)*scale-1),fill=(235,245,255,255))
  x+=5*scale
def save(path,kind,meta={}):
 p=out/path; manifest.append({'path':path,'kind':kind,'license':'CC0-1.0','origin':'independently authored procedural TEST placeholder; not original pixels/audio','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**meta})
text=(src/'assets/image.go').read_text()
for m in re.finditer(r'(Image\w+)\s*:\s*\{([^}]+)\}',text):
 id,body=m.groups(); path=re.search(r'Path:\s*"([^"]+)"',body).group(1)
 fw=re.search(r'FrameWidth:\s*(\d+)',body);fh=re.search(r'FrameHeight:\s*(\d+)',body);fw=int(fw.group(1)) if fw else 0;fh=int(fh.group(1)) if fh else 0
 # Frame-grid counts are conservative TEST allocations, not recovered original metadata.
 w,h=(fw or 32),(fh or (fw if fw else 32));cols=16 if fw else 1;rows=4 if fh else 1
 if path in ('image/drones/worker_agent.png','image/drones/courier_agent.png'):
  cols=4;rows=3 # Independently chosen4-frame cycle and source rank0..2 rows.
 if '/ebitenui/' in path:w=h=32;cols=rows=1
 if '/landscape/' in path and path.endswith('/tiles.png'):w=h=32;cols=8;rows=1
 if path=='image/logo.png':w,h=320,72;cols=rows=1
 if '/shadows/' in path:w,h=24,12
 if 'priority_bar' in path:w,h=100,12
 im=Image.new('RGBA',(w*cols,h*rows));d=ImageDraw.Draw(im);seed=hashlib.sha256(path.encode()).digest();c=tuple(70+b%140 for b in seed[:3])+(255,)
 for y in range(rows):
  for x in range(cols):
   x0,y0=x*w,y*h
   if '/landscape/' in path:
    d.rectangle((x0,y0,x0+w-1,y0+h-1),fill=(28+seed[0]%25,38+seed[1]%25,48+seed[2]%25,255));d.line((x0,y0,x0+w-1,y0+h-1),fill=(60,75,90,255))
   elif '/ebitenui/' in path:d.rectangle((x0,y0,x0+w-1,y0+h-1),fill=(25,35,50,245),outline=(80,135,175,255),width=2)
   elif '/resources/' in path:
    cx,cy=x0+w//2,y0+h//2
    radius=max(1,int(min(w,h)*0.45*(1-x/max(1,cols))))
    d.polygon([(cx,cy-radius),(cx+radius,cy),(cx,cy+radius),(cx-radius,cy)],fill=(70,205,155,255),outline=(235,245,255,255))
   elif '/creeps/' in path:
    d.polygon([(x0+w//2,y0+1),(x0+w-2,y0+h-2),(x0+1,y0+h-2)],fill=(210,95,85,255),outline=(235,245,255,255))
   elif '/drones/' in path:
    inset=1+x%2
    d.ellipse((x0+inset,y0+inset,x0+w-inset-1,y0+h-inset-1),fill=(75,170,230,255),outline=(235,245,255,255))
    d.line((x0+1,y0+h//2,x0+w-2,y0+h//2),fill=(20,40,70,255))
   elif 'colony' in path or 'turret' in path or '/buildings/' in path:
    d.rectangle((x0+1,y0+1,x0+w-2,y0+h-2),fill=(180,145,65,255),outline=(235,245,255,255))
   else:
    pad=max(1,min(w,h)//4)
    d.ellipse((x0+pad,y0+pad,x0+w-pad-1,y0+h-pad-1),fill=c,outline=(235,245,255,255));d.line((x0+w//2,y0+2,x0+w//2,y0+h-3),fill=(20,25,40,255));d.line((x0+2,y0+h//2,x0+w-3,y0+h//2),fill=(20,25,40,255))
   # Independently authored directional barrel, matching the source's indexed10-view contract.
   if ('turret' in path or 'howitzer_trunk' in path) and fw and 'damage_mask' not in path:
    cx,cy=x0+w//2,y0+h//2
    angles=(0.225,0.8,math.pi/2,math.pi-0.8,math.pi-0.3,math.pi+0.225,math.pi+0.8,1.5*math.pi,2*math.pi-0.8,2*math.pi-0.3)
    angle=angles[x%10]
    reach=max(2,min(w,h)//3)
    tip=(cx+int(math.cos(angle)*reach),cy+int(math.sin(angle)*reach))
    d.line((cx,cy,*tip),fill=(255,230,130,255),width=2)
    d.ellipse((cx-1,cy-1,cx+1,cy+1),fill=(35,45,55,255))
   if '/drones/' in path and fh:
    for pip in range(min(y,2)):
     d.rectangle((x0+2+pip*3,y0+2,x0+3+pip*3,y0+3),fill=(255,210,60,255))
   # Independent per-type marks preserve broad class colors while distinguishing units.
   if '/drones/' in path or '/creeps/' in path:
    cx,cy=x0+w//2,y0+h//2
    mark=seed[3]%4
    ink=(245,245,220,255)
    if mark==0:d.line((cx-2,cy,cx+2,cy),fill=ink)
    elif mark==1:d.line((cx,cy-2,cx,cy+2),fill=ink)
    elif mark==2:
     d.line((cx-2,cy-2,cx+2,cy+2),fill=ink)
     d.line((cx-2,cy+2,cx+2,cy-2),fill=ink)
    else:d.rectangle((cx-1,cy-1,cx+1,cy+1),outline=ink)
 if path=='image/logo.png':d.rectangle((0,0,319,71),fill=(20,30,45));draw_label(d,'ROBODEN',15,10);draw_label(d,'TEST',15,40,3)
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
 save(path,'png',{'source_id':id,'source_frame_width':fw,'source_frame_height':fh,'test_width':im.width,'test_height':im.height,'test_grid':[cols,rows],'animation_contract':('authored4-frame cycle,3rank rows' if path in ('image/drones/worker_agent.png','image/drones/courier_agent.png') else 'provisional allocation; per-image review pending'),'original_total_dimensions':'unknown; not inspected','evidence':'src/assets/image.go'})
for path in sorted(set(re.findall(r'Path:\s*"([^"$]+\.wav)"',(src/'assets/audio.go').read_text()))):
 if not path.startswith('sfx/'):continue
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True)
 with wave.open(str(p),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(44100);w.writeframes(bytes(4410*4))
 save(path,'silent-test-wav')
p=out/'music/silent.wav';p.parent.mkdir(parents=True,exist_ok=True)
with wave.open(str(p),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(44100);w.writeframes(bytes(44100*4))
save('music/silent.wav','silent-test-wav')
for path in re.findall(r'Path:\s*"([^"]+)"',(src/'assets/shader.go').read_text()):
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('//kage:unit pixels\npackage main\nfunc Fragment(position vec4, texCoord vec2, color vec4) vec4 { return imageSrc0At(texCoord) }\n');save(path,'test-pass-through-shader')
keys=set()
for p in src.rglob('*.go'):
 if '_data' in p.parts:continue
 t=p.read_text(encoding='utf8');
 for args in re.findall(r'\.Get(?:TitleCase)?\(([^\n)]*)\)',t):
  strs=re.findall(r'"([\w.]+)"',args)
  if strs:keys.add('.'.join(strs))
labels={'menu.main.play':'Play','menu.main.options':'Options','menu.main.exit':'Exit','menu.back':'Back','menu.next':'Next','menu.main.credits':'Credits','boot.title':'Loading independent test pack'}
labels.update({'tutorial.greeting':'Build a colony and keep its drones supplied. Continue when ready.', 'tutorial.resources':'Nearby resource deposits supply your colony. Move close enough for workers to gather.', 'tutorial.move.keyboard':'Right-click near a resource deposit to relocate the selected colony.', 'tutorial.move.mouse':'Right-click near a resource deposit to relocate the selected colony.', 'tutorial.camera.keyboard':'Use the arrow keys to inspect the surrounding terrain. Click this message to continue.', 'tutorial.priorities.keyboard':'Set colony priorities to direct resource gathering and drone production.', 'tutorial.enable_choices.keyboard':'Press a number key from 1 to 5 to apply a colony priority choice.'})
labels.update({
 'tutorial.enemy_scouts':'Enemy scouts are approaching. Keep defensive drones ready.',
 'tutorial.factions':'Priority choices also select a faction for future drones.',
 'tutorial.factions2.keyboard':'Hold Alt to inspect drone recipes. Click this message to continue.',
 'tutorial.build_turret.keyboard':'Choose the offered turret construction command to defend your colony.',
 'tutorial.crawlers_attack':'Ground attackers are approaching your colony. Protect your workers.',
 'tutorial.builders_attack':'Enemy builders can establish new threats. Watch their positions.',
 'tutorial.final_attack_warning':'A stronger wave is approaching. Prepare your defenses.',
 'tutorial.final_attack':'The final wave has arrived. Defend the colony and defeat the attackers.',
 'tutorial.final_goal':'Defeat the marked artillery unit to finish the exercise.',
 'tutorial.final_message':'The exercise is complete. Click this message to open the results.',
 'tutorial.context.resource_bar':'This bar shows stored colony resources. Workers replenish it and construction spends it.',
 'tutorial.next.keyboard':'Click this message to continue.'
})
labels.update({'menu.results.victory':'Victory','menu.results.defeat':'Defeat'})
# Runtime combines base dictionary keys with input-mode suffixes.
# Use original diagnostic labels rather than unresolved {{key}} tokens.
for key in list(keys):
 if key.startswith('tutorial.'):
  for mode in ('keyboard','mouse','gamepad'):
   keys.add(key+'.'+mode)
keys.update(labels)
body=''.join('## '+k+': '+labels.get(k,k.split('.')[-1].replace('_',' ').title())+'\n' for k in sorted(keys))
for lang in ('en','ru'):
 for suffix in ('','_intro','_achievements','_drones'):
  path=f'raw/{lang}{suffix}.txt';p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body if not suffix else '',encoding='utf8');save(path,'authored-test-labels')
for name in ('tiles','forest_tiles','inferno_tiles','snow_tiles'):
 path=f'raw/{name}.json';(out/path).write_text(json.dumps({'type':'tileset','tilecount':8,'columns':8,'tilewidth':32,'tileheight':32}));save(path,'authored-test-tileset')
(root/'replacement-asset-manifest.json').write_text(json.dumps({'status':'PRIVATE STARTUP/GAMEPLAY HARNESS ONLY; provisional, not polished replacements','source_commit':'9a5d355f3ddcd0767c9083233bc814f0b54246cf','license':'CC0-1.0','read_original_pixels_audio':False,'files':manifest},indent=2));print(len(manifest),'test assets generated')

















