//kage:unit pixels
package main
func Fragment(position vec4, texCoord vec2, color vec4) vec4 { return imageSrc0At(texCoord) }
