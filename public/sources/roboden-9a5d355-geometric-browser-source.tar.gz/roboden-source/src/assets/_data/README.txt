Private compile sentinel; no upstream game media. This build cannot play until licensed replacement assets are supplied.
