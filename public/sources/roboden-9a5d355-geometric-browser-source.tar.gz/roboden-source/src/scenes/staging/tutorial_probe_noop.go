//go:build !robodenprobe || !js || !wasm

package staging

func observeTutorial(m *tutorialManager) {}
