# From src/, use Go 1.27.2. No diagnostic tag.
GOOS=js GOARCH=wasm CGO_ENABLED=0 go build -p 2 -ldflags="-s -w" -tags itchio -trimpath -o ../browser/main.wasm ./cmd/game
