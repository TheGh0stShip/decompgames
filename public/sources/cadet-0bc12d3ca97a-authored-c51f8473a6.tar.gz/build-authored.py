from pathlib import Path
import re,subprocess,shutil,os
r=Path(__file__).resolve().parent
sources=[str(p.relative_to(r)) for p in (r/'SpaceCadetPinball').glob('*.cpp') if p.name not in ['gm_sf2.cpp','tsf.cpp']]
flags=['-std=c++11','-O1','-Wno-nontrivial-memcall','-DMUSIC_SDL','-sUSE_SDL=2','-sUSE_SDL_MIXER=2','-sALLOW_MEMORY_GROWTH=1','-sFORCE_FILESYSTEM=1','-sEXPORTED_RUNTIME_METHODS=["FS","IDBFS","callMain"]','-lidbfs.js','--bind','--preload-file','authored-resources@game_resources','-o','bin/authored-cadet.js'];(r/'bin').mkdir(exist_ok=True)
with (r/'authored-build.log').open('w') as log:
 result=subprocess.run([os.environ.get('EMXX','em++')]+sources+flags,cwd=r,stdout=log,stderr=subprocess.STDOUT)
print('exit',result.returncode);print((r/'authored-build.log').read_text()[-2500:])
