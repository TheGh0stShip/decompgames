#include "pch.h"
#include "pinball.h"
#include "memory.h"
#include "winmain.h"

// Todo: load translations from file
// Authored replacement resource text; CC0-1.0. Functional identifiers retain upstream scope.
std::map<uint32_t, LPCSTR> rc_strings
{
    {0, "Replay ready"},
    {1, "Ball captured"},
    {2, "Post reward\n%ld"},
    {3, "Points added\n%ld"},
    {4, "Bonus active"},
    {5, "Equipment tier up"},
    {6, "Drive tier up"},
    {7, "Million bonus"},
    {8, "Extra ball ready\n%ld"},
    {9, "Extra ball"},
    {10, "Quick shot bonus\n%ld"},
    {11, "Final task clear"},
    {12, "Chute reward\n%ld"},
    {13, "Chute reward ready"},
    {14, "Prize collected\n%ld"},
    {15, "Prize ready"},
    {16, "Multiple balls"},
    {17, "Ramp reward"},
    {18, "Lamp added"},
    {19, "Ramp reward on"},
    {20, "Lamp reset off"},
    {21, "Launch skill bonus\n%ld"},
    {22, "Paused\nF3 continues"},
    {23, "Continue"},
    {24, "F2 begins a round"},
    {25, "Watch the table"},
    {26, "Player 1"},
    {27, "Player 2"},
    {28, "Player 3"},
    {29, "Player 4"},
    {30, "Demo\nPlayer 1"},
    {31, "Demo\nPlayer 2"},
    {32, "Demo\nPlayer 3"},
    {33, "Demo\nPlayer 4"},
    {34, "Round finished"},
    {35, "Table tilted"},
    {36, "Processor unsupported"},
    {37, "Processor check"},
    {38, "Open Cadet"},
    {39, "Use distinct keys\nFor each control"},
    {40, "Erase saved records?"},
    {41, "Confirm choice"},
    {42, "WAVEMIX.INF is missing - it must be in the pinball directory!"},
    {43, "Notice"},
    {44, "Fuel restored"},
    {45, "Gravity zone"},
    {46, "Advance a tier"},
    {47, "Return a tier"},
    {48, "Storm bonus"},
    {49, "Portal"},
    {50, "Hold Space\nRelease to fire"},
    {51, "Flag tier up"},
    {52, "Keep bonus"},
    {53, "Award tier 1"},
    {54, "Award tier 2"},
    {55, "Award tier 3"},
    {56, "Score factor 2"},
    {57, "Score factor 3"},
    {58, "Score factor 5"},
    {59, "Score factor 10"},
    {60, "Aim test"},
    {61, "Ramp test"},
    {62, "Return test"},
    {63, "Lab task"},
    {64, "Rock task"},
    {65, "Void task"},
    {66, "Shield task"},
    {67, "Sweep task"},
    {68, "Defend task"},
    {69, "Assist task"},
    {70, "Relay task"},
    {71, "Scout task"},
    {72, "Device task"},
    {73, "Cleanse task"},
    {74, "Hidden task"},
    {75, "Clock task"},
    {76, "Storm task"},
    {77, "Objective started\n%ld"},
    {78, "Objective cleared\n%ld"},
    {79, "Objective chosen\n%s"},
    {80, "Void reward\n%ld"},
    {81, "Gravity reset\n%ld"},
    {82, "Gravity reward\n%ld"},
    {83, "New rank\n%s"},
    {84, "Starter"},
    {85, "Explorer"},
    {86, "Navigator"},
    {87, "Pilot"},
    {88, "Squad lead"},
    {89, "Team lead"},
    {90, "Wing lead"},
    {91, "Sector lead"},
    {92, "Chief pilot"},
    {93, "Portal ready"},
    {94, "Impact reward\n%ld"},
    {95, "Replay ball"},
    {96, "Launch again"},
    {97, "Player 1\nTry again"},
    {98, "Player 2\nTry again"},
    {99, "Player 3\nTry again"},
    {100, "Player 4\nTry again"},
    {101, "Independent replacement edition for the SpaceCadetPinball engine. Engine and dependencies retain their notices."},
    {102, "Open Cadet replacement edition. See distributed licences and provenance."},
    {103, "About Open Cadet"},
    {104, "Hit targets\nPick a task"},
    {105, "Hit fuel marks"},
    {106, "Use ramp\nStart task\n%s"},
    {107, "Bumper hits left\n%d"},
    {108, "Aim test clear"},
    {109, "Objective ended"},
    {110, "Ramp shots left\n%d"},
    {111, "Ramp test clear"},
    {112, "Returns left\n%d"},
    {113, "Return test clear"},
    {114, "Drop marks left\n%d"},
    {115, "Lab task clear"},
    {116, "Fuel is low"},
    {117, "Right marks"},
    {118, "Use upper chute"},
    {119, "Rock task clear"},
    {120, "Use portal"},
    {121, "Shield task clear"},
    {122, "Raise ramp tier"},
    {123, "Use void hole"},
    {124, "Void task clear"},
    {125, "Marks left\n%d"},
    {126, "Sweep task clear"},
    {127, "Raise flag tier"},
    {128, "Use upper chute"},
    {129, "Assist task clear"},
    {130, "Defend task clear"},
    {131, "Hit fuel marks"},
    {132, "Far bumper left\n%d"},
    {133, "Relay task clear"},
    {134, "Lane trips left\n%d"},
    {135, "Use fuel lane"},
    {136, "Scout task clear"},
    {137, "Outer lanes left\n%d"},
    {138, "Device task clear"},
    {139, "Flag rolls left\n%d"},
    {140, "Hit upper roll"},
    {141, "Cleanse clear"},
    {142, "Yellow portal"},
    {143, "Red portal"},
    {144, "Green portal"},
    {145, "Hidden task clear"},
    {146, "Rebounds left\n%d"},
    {147, "Use chute\nOr ramp"},
    {148, "Drop hits left\n%d"},
    {149, "Spot hits left\n%d"},
    {150, "Lane trips left\n%d"},
    {151, "Use fuel lane"},
    {152, "Hit ramp"},
    {153, "Hit flags"},
    {154, "Hit portal"},
    {155, "Chute storm"},
    {156, "pinball.mid"},
    {158, "1 UseBitmapFont"},
    {159, "90 Left Flipper Key"},
    {160, "191 Right Flipper Key"},
    {161, "32 Plunger Key"},
    {162, "88 Bump Left Key"},
    {163, "190 Bump Right Key"},
    {164, "38 Bump Bottom Key"},
    {165, "Software\\Microsoft\\Plus!\\Pinball"},
    {166, "SpaceCadet"},
    {167, "1c7c22a0-9576-11ce-bf80-444553540000"},
    {168, "PINBALL.DAT"},
    {169, "Open Cadet"},
    {170, "Could not proceed"},
    {171, "No extra tables found"},
    {172, "Open Cadet\nReady to play"},
    {173, "New rank\n%s"},
    {174, "Rank reduced\n%s"},
    {175, "Raise bumper tier"},
    {176, "Left marks"},
    {177, "Best score"},
    {178, "pinball.chm"},
    {179, "Memory unavailable"},
    {180, "Player 1 score\n%ld"},
    {181, "Player 2 score\n%ld"},
    {182, "Player 3 score\n%ld"},
    {183, "Player 4 score\n%ld"},
    {184, "Record 1\n%ld"},
    {185, "Record 2\n%ld"},
    {186, "Record 3\n%ld"},
    {187, "Record 4\n%ld"},
    {188, "Record 5\n%ld"},
    {189, "255 255 255"},
    {2030, "Fit 640 x 480"},
    {2031, "Fit 800 x 600"},
    {2032, "Fit 1024 x 768"},
};

int LoadStringAlt(uint32_t uID, LPSTR lpBuffer, int cchBufferMax)
{
	auto str = rc_strings.find(uID);
	if (str == rc_strings.end())
	{		
		return 0;
	}

	strncpy(lpBuffer, str->second, cchBufferMax);
	return 1;
}

int pinball::quickFlag = 0;
TTextBox* pinball::InfoTextBox;
TTextBox* pinball::MissTextBox;
char pinball::getRcBuffer[6 * 256];
int pinball::rc_string_slot = 0;
int pinball::LeftShift = -1;
int pinball::RightShift = -1;

char* pinball::get_rc_string(int uID, int a2)
{
	char* result = &getRcBuffer[256 * rc_string_slot];
	if (!LoadStringAlt(uID, &getRcBuffer[256 * rc_string_slot], 255))
		*result = 0;
	if (++rc_string_slot >= 6)
		rc_string_slot = 0;
	return result;
}

int pinball::get_rc_int(int uID, int* dst)
{
	char buffer[255];
	int result = LoadStringAlt(uID, buffer, 255);
	if (!result)
		return result;
	*dst = atoi(buffer);
	return 1;
}

std::string pinball::make_path_name(const std::string& fileName)
{
	return winmain::BasePath + fileName;
}
