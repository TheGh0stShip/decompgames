from pathlib import Path
import struct,json,hashlib
p=Path(__file__).parent;raw=bytearray((p/'PINBALL.DAT').read_bytes());count=struct.unpack_from('<H',raw,175)[0];pos=183+struct.unpack_from('<H',raw,181)[0];records=[];palette=None
for gi in range(count):
 n=raw[pos];pos+=1
 for _ in range(n):
  typ=raw[pos];pos+=1;size=2 if typ in [0,2] else 0 if typ==13 else struct.unpack_from('<I',raw,pos)[0]
  if typ not in [0,2,13]:pos+=4
  if typ==1 and 5<=gi<=14:records.append((gi,pos,size))
  if typ==5:palette=bytes(raw[pos:pos+size])
  pos+=size
assert len(records)==10 and palette
colors=[tuple(palette[i:i+4]) for i in range(0,len(palette),4)];ink=max(range(1,256),key=lambda i:sum(colors[i][:3]))
# Independently specified seven-segment raster geometry, no font or retail glyph input.
segments={'a':(3,2,11,3),'b':(11,3,12,10),'c':(11,11,12,18),'d':(3,18,11,19),'e':(2,11,3,18),'f':(2,3,3,10),'g':(3,10,11,11)}
active=['abcdef','bc','abdeg','abcdg','bcfg','acdfg','acdefg','abc','abcdefg','abcdfg'];changes=[]
for gi,offset,size in records:
 header=struct.unpack_from('<BhhhhIB',raw,offset);assert header[1:3]==(15,22) and header[-1]==1
 pixels=bytearray(header[-2]);stride=header[-2]//22
 for seg in active[gi-5]:
  x0,y0,x1,y1=segments[seg]
  for y in range(y0,y1+1):
   for x in range(x0,x1+1):pixels[(21-y)*stride+x]=ink
 raw[offset+14:offset+size]=pixels;changes.append({'group':gi,'digit':gi-5,'bitmapSHA256':hashlib.sha256(pixels).hexdigest()})
assert len({c['bitmapSHA256'] for c in changes})==10
(p/'PINBALL-digits.DAT').write_bytes(raw);(p/'digits-provenance.json').write_text(json.dumps({'license':'CC0-1.0','origin':'Independently specified seven-segment rectangles; no source font/retail glyph input','baseDataSHA256':hashlib.sha256((p/'PINBALL.DAT').read_bytes()).hexdigest(),'dataSHA256':hashlib.sha256(raw).hexdigest(),'inkPaletteIndex':ink,'changes':changes},indent=2))
print(json.dumps({'bytes':len(raw),'ink':ink,'sha256':hashlib.sha256(raw).hexdigest()}))
